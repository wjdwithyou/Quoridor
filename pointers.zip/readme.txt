These icons are from Icojam (http://www.icojam.com)

Hand pointers icons

Ammount of icons:
36

File Types:
.png
.psd